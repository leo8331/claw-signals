"""CLAW首页生成器 — 设计版(style.css + 统一导航 + LIVE信号条 + 模块大卡)"""
import os, json, re
from datetime import datetime

hist_base = 'D:/tdx临时/历史数据'
dates = sorted([d for d in os.listdir(hist_base) if os.path.isdir(f'{hist_base}/{d}') and re.match(r'^\d{4}-\d{2}-\d{2}$', d)], reverse=True)
latest = dates[0] if dates else ''
today_str = datetime.now().strftime('%Y-%m-%d')

def loadj(p):
    return json.load(open(p, 'r', encoding='utf-8')) if os.path.exists(p) else []

def sig_list(name):
    d = loadj(f'{hist_base}/{latest}/results_{name}.json')
    if isinstance(d, dict):
        return d.get('ht_rise', d.get('all', []))
    return d

# ── 仓位 ──
real_pct, sug_pct, has_pos = 0, 0, False
def pos_color(v):
    if v >= 100: return ('#17bf63', '满仓')
    if v >= 50:  return ('#f5a623', '半仓')
    if v >= 25:  return ('#8899a6', '轻仓')
    return ('#e0245e', '空仓')
if latest:
    pj = f'{hist_base}/{latest}/position.json'
    if os.path.exists(pj):
        p = json.load(open(pj, 'r', encoding='utf-8'))
        real_pct, sug_pct, has_pos = p.get('real', 0), p.get('suggest', 0), True
rc, rl = pos_color(real_pct)
sc, sl = pos_color(sug_pct)

# ── 信号统计 (最新日期) ──
h3, g, m5 = sig_list('h3'), sig_list('g'), sig_list('m5')
n_h3, n_g, n_v5 = len(h3), len(g), len(m5)
n_sig = n_h3 + n_g + n_v5

# ── 行业数据 (LIVE条 + 行业卡预览 + 存档表) ──
sector_latest = loadj(f'{hist_base}/{latest}/results_sector.json')
top5 = sorted(sector_latest, key=lambda r: -r.get('r20', 0))[:5]
lead = top5[0] if top5 else None
lead_txt = f"领涨 {lead['name']} {lead['r20']:+.2f}%" if lead else '—'

def cn_color(v):
    return 'var(--red)' if v > 0 else 'var(--green)' if v < 0 else 'var(--text-tertiary)'

tick_items = ''.join(
    f'<span class="tick-item"><span class="t">{i+1:02d}</span><span>{r["name"]}</span>'
    f'<span class="mono" style="color:{cn_color(r["r20"])}">{r["r20"]:+.1f}%</span></span>'
    for i, r in enumerate(top5)
)

# ── 仓位分段条 ──
segs = ''.join(f'<span class="seg{" on" if i < round(real_pct/10) else ""}"></span>' for i in range(10))
pos_card = f'''<div class="card" style="margin-bottom:24px">
  <div class="page-head-row" style="margin-bottom:14px">
    <div class="mod-title" style="margin-bottom:0">当前仓位 · 市场信号</div>
    <div class="mono" style="font-size:11px;color:var(--text-muted)">{latest} 收盘</div>
  </div>
  <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap">
    <div style="min-width:90px">
      <div class="mono" style="font-size:28px;font-weight:500;color:var(--accent);line-height:1.1">{real_pct}%</div>
      <div style="font-size:11px;color:var(--text-muted)">真实仓位 · 建议 {sug_pct}%</div>
    </div>
    <div style="flex:1;min-width:220px">
      <div class="seg-bar">{segs}<span class="mono" style="font-size:11px;color:var(--accent);margin-left:8px">{round(real_pct/10)}/10</span></div>
      <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:6px">
        <span>0 防守</span><span>50 中性</span><span>100 进攻</span>
      </div>
    </div>
  </div>
</div>''' if has_pos else ''

# ── 模块大卡 (SVG 图标 + 真实预览数据) ──
ICONS = {
    'target': '<svg viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="6.2" stroke="#fff" stroke-width="1.6"/><circle cx="9" cy="9" r="2" stroke="#fff" stroke-width="1.6"/><path d="M9 1.2v2.4M9 14.4v2.4M1.2 9h2.4M14.4 9h2.4" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'bars':   '<svg viewBox="0 0 18 18" fill="none"><path d="M3.5 15V8.5M9 15V3.5M14.5 15v-5" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/></svg>',
    'gem':    '<svg viewBox="0 0 18 18" fill="none"><path d="M9 2.8l5 3.7L9 15.2 4 6.5l5-3.7z" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/><path d="M4 6.5h10" stroke="#fff" stroke-width="1.5"/></svg>',
    'line':   '<svg viewBox="0 0 18 18" fill="none"><path d="M2.5 14l4-5 3.5 3 5.5-7" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M11.5 5h4v4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
}
def mod_card(href, icon, title, desc, stat):
    return f'''<a href="{href}" class="card mod-card">
  <div class="mod-top"><span class="mod-icon">{ICONS[icon]}</span><span class="mod-arrow">→</span></div>
  <div class="mod-title">{title}</div>
  <div class="mod-desc">{desc}</div>
  <div class="mod-foot"><span class="mod-stat">{stat}</span><span class="mod-link">进入模块 →</span></div>
</a>'''

cards = '\n'.join([
    mod_card('每日选股/', 'target', '每日选股', '每日 15:00 自动扫描全 A 信号，H3 / G / V5 三策略分级，含仓位与止损建议。',
             f'今日信号 {n_sig} · H3 {n_h3} / G {n_g} / V5 {n_v5}'),
    mod_card('行业排行/', 'bars', '行业排行', '行业 20 日涨幅排序与阶段识别，定位产业链主线与领涨龙头。', lead_txt),
    mod_card('价值投资/', 'gem', '价值投资', '六步产业价值投资工作流：抓取、验证、瓶颈、评分、估值、入池。', '方法论 · 估值建模 · 每日产业分析'),
    mod_card('回测报告/', 'line', '回测报告', 'H3 v4.2 模拟交易全记录：净值曲线、持仓明细与胜率统计。', 'H3 v4.2 · 50 万模拟盘'),
])

html = f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>CLAW 量化交易信号平台</title>
<link rel="stylesheet" href="style.css">
<style>
.hero-label{{font-family:var(--mono);font-size:11px;font-weight:600;color:var(--accent);letter-spacing:3px;margin-bottom:10px}}
.hero-sub{{font-size:13px;color:var(--text-secondary);margin-top:8px}}
</style></head>
<body class="entrance-ready">

<div class="top-accent-strip"></div>
<div class="deco-streak deco-streak-h"></div>
<div class="deco-streak deco-streak-h2"></div>
<div class="deco-orb deco-orb-subtle"></div>
<div class="deco-orb deco-orb-mini"></div>

<nav class="top-nav"><div class="nav-inner">
  <a href="./" class="nav-brand">CLAW</a>
  <a href="./" class="nav-link nav-active">首页</a>
  <a href="每日选股/" class="nav-link hide-m">每日选股</a>
  <a href="行业排行/" class="nav-link hide-m">行业排行</a>
  <a href="价值投资/" class="nav-link hide-m">价值投资</a>
  <a href="回测报告/" class="nav-link hide-m">回测报告</a>
  <a href="历史数据/" class="nav-link hide-m">历史数据</a>
  <div class="nav-right"><span class="nav-status"><span class="live-dot"></span>{latest[5:] if latest else ''} 已更新</span></div>
</div></nav>

<main>
  <div class="page-header">
    <div class="hero-label">A股量化交易系统</div>
    <h1>CLAW 量化交易信号平台</h1>
    <div class="hero-sub">H3 · G · V5 三策略信号 ｜ 六步产业价值投资工作流 ｜ TDX 实时行情驱动</div>
  </div>

  <div class="card" style="padding:0;margin-bottom:24px">
    <div class="tick-strip">
      <span class="live-pill">LIVE</span>
      {tick_items}
      <span style="font-size:10px;color:var(--text-muted);white-space:nowrap">20日领涨 · 每日 15:00 更新</span>
    </div>
  </div>

  {pos_card}

  <div class="mod-grid">
{cards}
  </div>

  <div class="text-center mt-24">
    <a href="历史数据/" style="font-size:13px">历史数据存档（{len(dates)} 个交易日）→</a>
  </div>
</main>

<footer>CLAW Signals · 部署于 GitHub Pages ｜ 数据源 TDX · 每日 15:00 自动构建 ｜ © {datetime.now().strftime('%Y')} leo8331</footer>
</body></html>'''

with open('D:/tdx临时/index.html', 'w', encoding='utf-8') as f:
    f.write(html)

# ═══ 历史数据存档页 ═══
WEEK_CN = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

def day_info(d):
    """每个存档日的 信号数/领涨行业"""
    h = sig_list_for(d, 'h3'); g_ = sig_list_for(d, 'g'); m = sig_list_for(d, 'm5')
    sec = loadj(f'{hist_base}/{d}/results_sector.json')
    top = max(sec, key=lambda r: r.get('r20', 0)) if sec else None
    return len(h) + len(g_) + len(m), top

def sig_list_for(d, name):
    dd = loadj(f'{hist_base}/{d}/results_{name}.json')
    if isinstance(dd, dict):
        return dd.get('ht_rise', dd.get('all', []))
    return dd

rows_by_month = {}
for d in dates:
    n, top = day_info(d)
    wd = WEEK_CN[datetime.strptime(d, '%Y-%m-%d').weekday()]
    lead_cell = f'{top["name"]}' if top else '—'
    lead_chg = f'<span class="mono" style="color:{cn_color(top["r20"])}">{top["r20"]:+.1f}%</span>' if top else '—'
    row = (f'<tr><td><a href="./{d}/" class="mono" style="color:var(--text-primary);font-weight:600">{d}</a></td>'
           f'<td style="color:var(--text-muted)">{wd}</td>'
           f'<td class="mono">{n}</td><td>{lead_cell}</td><td>{lead_chg}</td>'
           f'<td><a href="./{d}/">选股</a> · <a href="./{d}/sector.html">行业</a></td></tr>')
    rows_by_month.setdefault(d[:7], []).append(row)

month_blocks = ''
for m in sorted(rows_by_month.keys(), reverse=True):
    month_blocks += (f'<div class="month-label">{m}</div>'
                     f'<div class="card" style="padding:4px 8px"><div class="table-wrap"><table style="margin:0">'
                     f'<tr><th>日期</th><th>星期</th><th>信号数</th><th>领涨行业</th><th>20日涨幅</th><th>操作</th></tr>'
                     + '\n'.join(rows_by_month[m]) + '</table></div></div>')

hist_html = f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>历史数据存档 · CLAW</title>
<link rel="stylesheet" href="../style.css">
</head><body class="entrance-ready">
<div class="top-accent-strip"></div>
<div class="deco-streak deco-streak-h"></div>
<div class="deco-orb deco-orb-subtle"></div>

<div class="content-panel">
<nav class="sub-nav">
  <span class="sub-nav-home" onclick="window.location.href='../index.html'">HOME_</span>
  <span class="sub-nav-modules" onclick="openModuleMenu()">MODULES ▾</span>
  <span class="sub-nav-switch" onclick="window.location.href='../每日选股/index.html'">SWITCH_</span>
</nav>
<div class="sub-overlay-bg" id="overlayBg" onclick="closeModuleMenu()"></div>
<div class="sub-overlay-menu" id="overlayMenu">
  <div class="sub-menu-close" onclick="closeModuleMenu()"></div>
  <div class="sub-menu-section">策略模块</div>
  <a class="sub-menu-link" href="../每日选股/index.html"><span class="sub-menu-dot" style="background:#6699E0"></span>每日选股策略</a>
  <a class="sub-menu-link" href="../行业排行/index.html"><span class="sub-menu-dot"></span>行业排行</a>
  <a class="sub-menu-link" href="../价值投资/index.html"><span class="sub-menu-dot"></span>价值投资</a>
  <a class="sub-menu-link" href="../回测报告/index.html"><span class="sub-menu-dot"></span>回测报告</a>
  <div class="sub-menu-section">系统</div>
  <a class="sub-menu-link" href="../index.html"><span class="sub-menu-dot"></span>首页</a>
  <a class="sub-menu-link" href="./"><span class="sub-menu-dot"></span>历史数据</a>
</div>
<main>
  <div class="page-header page-head-row">
    <div>
      <div style="font-family:var(--mono);font-size:11px;font-weight:600;color:var(--accent);letter-spacing:3px;margin-bottom:8px">ARCHIVE</div>
      <h1>历史数据存档</h1>
      <div class="subtitle">每日信号与行业排行归档 · 选择日期查看当日完整页面</div>
    </div>
    <span class="date-chip">共 {len(dates)} 个交易日</span>
  </div>
  {month_blocks}
</main>
<footer>CLAW Signals · 历史数据存档 · {datetime.now().strftime('%Y')}</footer>
</div>
<script>
function openModuleMenu(){{document.getElementById('overlayBg').classList.add('open');document.getElementById('overlayMenu').classList.add('open')}}
function closeModuleMenu(){{document.getElementById('overlayBg').classList.remove('open');document.getElementById('overlayMenu').classList.remove('open')}}
document.addEventListener('keydown',function(e){{if(e.key==='Escape')closeModuleMenu()}});
</script>
</body></html>'''

with open('D:/tdx临时/历史数据/index.html', 'w', encoding='utf-8') as f:
    f.write(hist_html)

# ═══ 跳转页 (每日选股 / 行业排行) ═══
def redirect_page(title, icon, target):
    return f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{title} · CLAW</title>
<style>body{{background:#060610;color:#E8EBF0;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}}
.box{{text-align:center}}.box h1{{font-size:18px;color:#9BA3AF;margin-bottom:8px;font-weight:600}}.box p{{font-size:13px;color:#6B7280}}a{{color:#6699E0;text-decoration:none}}</style>
<meta http-equiv="refresh" content="0;url={target}"></head><body>
<div class="box"><h1>{icon} 跳转到最新{title}</h1><p>最新：{latest} ｜ <a href="../历史数据/">历史数据</a> ｜ <a href="../">首页</a></p></div>
</body></html>'''

with open('D:/tdx临时/每日选股/index.html', 'w', encoding='utf-8') as f:
    f.write(redirect_page('每日选股', '📊', f'../历史数据/{latest}/'))
with open('D:/tdx临时/行业排行/index.html', 'w', encoding='utf-8') as f:
    f.write(redirect_page('行业排行', '🏭', f'../历史数据/{latest}/sector.html'))

print(f'首页+历史数据+跳转页 已生成, {len(dates)} 个日期, 最新: {latest}')
