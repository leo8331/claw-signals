"""模拟交易HTML生成器 — 设计版(style.css + 统一导航 + KPI卡 + 基准线净值图)"""
import json,os
import numpy as np

def _cn(v):
    return 'var(--red)' if v>0 else 'var(--green)' if v<0 else 'var(--text-tertiary)'

def _stage(h):
    """板块阶段 pill (替代 emoji 箭头)"""
    ph = h.get('phase','')
    star = ' ★' if h.get('triple_up') else ''
    if ph.count('↑')>=2 or h.get('triple_up'):
        return f'<span class="stage-pill st-strong">强势{star}</span>'
    if ph.count('↓')>=2:
        return '<span class="stage-pill st-weak">弱势</span>'
    return '<span class="stage-pill st-mid">中性</span>' if ph else '<span style="color:var(--text-muted)">-</span>'

def _code_cls(c):
    c = str(c).replace('.SH','').replace('.SZ','')
    return ('code-sh' if c.startswith(('6','9')) else 'code-sz', c)

def _reason_col(reason):
    if reason=='买入': return 'var(--accent)'
    if '止盈' in reason: return 'var(--red)'
    if '止损' in reason: return 'var(--green)'
    return 'var(--orange)'  # EMA44 / 超时 等

def gen_html(p,today,tv,mv,ret_all):
    init=p['init'];cash=p['cash']
    trades=p['trades'];holds=p['holds'];curve=p['curve']
    wins=sum(1 for t in trades if t['profit']>0)
    wr=wins/len(trades)*100 if trades else 0
    wp=[t['profit'] for t in trades if t['profit']>0]
    lp=[t['profit'] for t in trades if t['profit']<=0]
    aw=np.mean(wp) if wp else 0;al=abs(np.mean(lp)) if lp else 0
    pf=aw/al if al>0 else 0
    # 回撤
    vals=[c['value'] for c in curve];pk=vals[0] if vals else init;mdd=0
    for v in vals:
        if v>pk:pk=v
        dd=(v/pk-1)*100
        if dd<mdd:mdd=dd
    # 持仓表
    hr=''
    for h in holds:
        r=(h.get('lp',h['bp'])/h['bp']-1)*100
        cls,nm_code=_code_cls(h["code"])
        nm=h.get('name','')
        hr+=(f'<tr><td><span class="{cls}">{nm_code}</span></td><td>{nm}</td>'
             f'<td>{_stage(h)}</td><td class="mono">{h["ed"]}</td>'
             f'<td class="mono">¥{h["bp"]:.2f}</td><td class="mono">¥{h.get("lp",h["bp"]):.2f}</td>'
             f'<td class="mono">{h["sh"]}</td><td class="mono">¥{h["cost"]:,.0f}</td>'
             f'<td class="mono" style="color:{_cn(r)};font-weight:600">{r:+.1f}%</td>'
             f'<td class="mono">{h.get("hd",0)}d</td><td class="mono">¥{h["sl"]:.2f}</td></tr>')
    if not hr:hr='<tr><td colspan=11 style="color:var(--text-muted);text-align:center">空仓</td></tr>'
    # 交易记录 (买入+卖出流水, 按日期倒序)
    tr=''
    for t in sorted(trades,key=lambda x:x.get('exit',''),reverse=True)[:50]:
        is_buy=t.get('reason','')=='买入'
        pcol=_cn(t['profit']) if not is_buy else 'var(--text-muted)'
        profit_str='—' if is_buy else f'¥{t["profit"]:+,.0f}'
        ret_str='—' if is_buy else f'{t["ret"]:+.1f}%'
        hold_str='—' if is_buy else f'{t["hold"]}d'
        cls,nm_code=_code_cls(t["code"])
        rcol=_reason_col(t["reason"])
        tr+=(f'<tr><td><span class="{cls}">{nm_code}</span></td><td class="mono">{t["entry"]}</td><td class="mono">{t["exit"]}</td>'
             f'<td class="mono">¥{t["buy"]:.2f}</td><td class="mono">¥{t["sell"]:.2f}</td><td class="mono">{t["sh"]}</td>'
             f'<td class="mono" style="color:{pcol};font-weight:600">{profit_str}</td>'
             f'<td class="mono" style="color:{pcol}">{ret_str}</td><td class="mono">{hold_str}</td>'
             f'<td style="color:{rcol};font-weight:600">{t["reason"]}</td></tr>')
    if not tr:tr='<tr><td colspan=10 style="color:var(--text-muted);text-align:center">暂无交易</td></tr>'
    # 曲线
    cl=json.dumps([c['date'] for c in curve])
    cv=json.dumps([c['value'] for c in curve])
    # 今日信号
    sigs=[h for h in holds if h['ed']==today]
    sig_html=''
    for s in sigs:
        sig_html+=f'<span class="tag tag-green" style="padding:4px 10px;font-size:11px;margin:2px">{s["code"]} {s.get("name","")} ¥{s["bp"]:.2f} {s["sh"]}股</span>'
    if not sig_html:sig_html='<span style="color:var(--text-muted);font-size:12px">今日无新开仓</span>'

    ODIR='D:/tdx临时/回测报告'
    html=f'''<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>H3 v4.2 模拟交易报告 | CLAW</title>
<link rel="stylesheet" href="../style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
.sig-strip{{text-align:center;margin-bottom:20px}}
.rep-table{{width:100%;border-collapse:collapse;font-size:13px}}
.rep-table th{{text-align:left;padding:9px 10px;color:var(--text-tertiary);font-weight:600;font-size:12px;border-bottom:2px solid rgba(56,61,77,0.3);white-space:nowrap}}
.rep-table td{{padding:9px 10px;border-bottom:1px solid rgba(56,61,77,0.12);vertical-align:middle}}
.rep-table tr:hover td{{background:rgba(102,153,224,0.05)}}
.chart-card{{padding:20px}}
.chart-card canvas{{width:100%!important;height:320px!important}}
.tw{{max-height:420px;overflow-y:auto}}
</style></head>
<body class="entrance-ready">

<div class="top-accent-strip"></div>
<div class="deco-streak deco-streak-h"></div>
<div class="deco-orb deco-orb-subtle"></div>

<div class="content-panel">
<nav class="sub-nav">
  <span class="sub-nav-home" onclick="window.location.href='../index.html'">HOME_</span>
  <span class="sub-nav-modules" onclick="openModuleMenu()">MODULES ▾</span>
  <span class="sub-nav-switch" onclick="window.location.href='../每日选股/index.html'">SWITCH_</span>
</nav>
<div class="sub-overlay-bg" id="overlayBg" onclick="closeModuleMenu()"></div>
<div class="sub-overlay-menu" id="overlayMenu">
  <div class="sub-menu-close" onclick="closeModuleMenu()"></div>
  <div class="sub-menu-section">策略模块</div>
  <a class="sub-menu-link" href="../每日选股/index.html"><span class="sub-menu-dot" style="background:#6699E0"></span>每日选股策略</a>
  <a class="sub-menu-link" href="../行业排行/index.html"><span class="sub-menu-dot"></span>行业排行</a>
  <a class="sub-menu-link" href="../价值投资/index.html"><span class="sub-menu-dot"></span>价值投资</a>
  <a class="sub-menu-link" href="./"><span class="sub-menu-dot"></span>回测报告</a>
  <div class="sub-menu-section">系统</div>
  <a class="sub-menu-link" href="../index.html"><span class="sub-menu-dot"></span>首页</a>
  <a class="sub-menu-link" href="../历史数据/index.html"><span class="sub-menu-dot"></span>历史数据</a>
</div>
<main>
  <div class="page-header page-head-row">
    <div>
      <div style="font-family:var(--mono);font-size:11px;font-weight:600;color:var(--accent);letter-spacing:3px;margin-bottom:8px">BACKTEST REPORT</div>
      <h1>H3 v4.2 模拟交易报告</h1>
      <div class="subtitle">初始 ¥{init:,} ｜ 起始 {p["start"]} ｜ 更新 {today} ｜ {len(trades)} 笔交易</div>
    </div>
    <span class="date-chip">{today}</span>
  </div>

  <div class="sig-strip">{sig_html}</div>

  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-label">总资产</div><div class="kpi-value" style="color:{_cn(ret_all)}">¥{tv:,.0f}</div><div class="kpi-delta">现金 ¥{cash:,.0f} ｜ 市值 ¥{mv:,.0f}</div></div>
    <div class="kpi-card"><div class="kpi-label">总收益</div><div class="kpi-value" style="color:{_cn(ret_all)}">{ret_all:+.1f}%</div><div class="kpi-delta">初始 ¥{init:,}</div></div>
    <div class="kpi-card"><div class="kpi-label">胜率 WR</div><div class="kpi-value">{wr:.1f}%</div><div class="kpi-delta">{wins}/{len(trades)} 笔盈利</div></div>
    <div class="kpi-card"><div class="kpi-label">盈亏比</div><div class="kpi-value">{pf:.2f}</div><div class="kpi-delta">赢 ¥{aw:,.0f} ｜ 亏 ¥{al:,.0f}</div></div>
    <div class="kpi-card"><div class="kpi-label">最大回撤</div><div class="kpi-value" style="color:var(--green)">{mdd:.1f}%</div><div class="kpi-delta">按净值曲线峰值计算</div></div>
    <div class="kpi-card"><div class="kpi-label">当前持仓</div><div class="kpi-value">{len(holds)}<span style="font-size:14px;color:var(--text-muted)">/5</span></div><div class="kpi-delta">单仓 20% 固定金额</div></div>
  </div>

  <div class="note-box"><b>策略:</b> H3 v4.2 橘黄→GAIN(2~20%)→HT上升[-π/2,0)→BQ≥0.6+EXH≤2 ｜ <b>仓位:</b> 20%×5 ｜ <b>止损:</b> -7%/7d ｜ <b>止盈:</b> +10%卖50%→+20%卖30% ｜ <b>清仓:</b> EMA44 ｜ <b>超时:</b> 60d</div>

  <div class="card chart-card" style="margin-bottom:24px">
    <div class="page-head-row" style="margin-bottom:12px">
      <div class="mod-title" style="margin-bottom:0">净值曲线</div>
      <div class="mono" style="font-size:11px;color:var(--text-muted)">基准: 初始资金 ¥{init:,}</div>
    </div>
    <canvas id="ec"></canvas>
  </div>

  <div class="card" style="padding:8px 12px;margin-bottom:24px">
    <div class="mod-title" style="padding:8px 4px 12px">当前持仓</div>
    <div class="table-wrap"><table class="rep-table" style="margin:0"><tr><th>代码</th><th>名称</th><th>板块阶段</th><th>买入日</th><th>买价</th><th>现价</th><th>股数</th><th>成本</th><th>浮盈</th><th>持仓</th><th>止损</th></tr>{hr}</table></div>
  </div>

  <div class="card" style="padding:8px 12px">
    <div class="mod-title" style="padding:8px 4px 12px">交易流水 <span style="font-size:11px;color:var(--text-muted);font-weight:400">近 50 笔 · 含买入</span></div>
    <div class="tw table-wrap"><table class="rep-table" style="margin:0"><tr><th>代码</th><th>买入日</th><th>日期</th><th>买价</th><th>价格</th><th>股数</th><th>盈亏</th><th>收益</th><th>持仓</th><th>原因</th></tr>{tr}</table></div>
  </div>
</main>
<footer>CLAW H3 v4.2 模拟交易 ｜ {today} ｜ ⚠ 仅供参考</footer>
</div>

<script>
function openModuleMenu(){{document.getElementById('overlayBg').classList.add('open');document.getElementById('overlayMenu').classList.add('open')}}
function closeModuleMenu(){{document.getElementById('overlayBg').classList.remove('open');document.getElementById('overlayMenu').classList.remove('open')}}
document.addEventListener('keydown',function(e){{if(e.key==='Escape')closeModuleMenu()}});

var l={cl},v={cv},initV={init};
var ctx=document.getElementById('ec').getContext('2d');
var grad=ctx.createLinearGradient(0,0,0,320);
grad.addColorStop(0,'rgba(102,153,224,0.20)');grad.addColorStop(1,'rgba(102,153,224,0)');
new Chart(ctx,{{
type:'line',
data:{{labels:l,datasets:[
  {{label:'策略净值',data:v,borderColor:'#6699E0',borderWidth:2,pointRadius:0,tension:0.25,fill:{{target:'origin',above:grad}}}},
  {{label:'初始资金',data:l.map(function(){{return initV}}),borderColor:'#F5A623',borderWidth:1,borderDash:[5,4],pointRadius:0,fill:false}}
]}},
options:{{responsive:true,maintainAspectRatio:false,interaction:{{mode:'index',intersect:false}},
plugins:{{
  legend:{{labels:{{color:'#9BA3AF',boxWidth:12,font:{{size:11}}}}}},
  tooltip:{{backgroundColor:'#16181D',borderColor:'#2E323A',borderWidth:1,titleColor:'#E8EBF0',bodyColor:'#9BA3AF',padding:10,
    callbacks:{{label:function(c){{return c.dataset.label+': ¥'+c.parsed.y.toLocaleString()}}}}}}
}},
scales:{{
  x:{{ticks:{{color:'#6B7280',maxTicksLimit:10,font:{{size:10}}}},grid:{{color:'rgba(255,255,255,0.04)'}}}},
  y:{{ticks:{{color:'#6B7280',font:{{size:10}},callback:function(v){{return '¥'+(v/10000).toFixed(0)+'万'}}}},grid:{{color:'rgba(255,255,255,0.04)'}}}}
}}
}}
}});
</script></body></html>'''
    with open(f'{ODIR}/index.html','w',encoding='utf-8') as f:f.write(html)
