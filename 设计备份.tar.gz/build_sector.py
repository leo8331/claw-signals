"""行业排行页面 — 设计版(style.css)"""
import os, json
from datetime import datetime

hist_base = 'D:/tdx临时/历史数据'
gen_date = datetime.now().strftime('%Y-%m-%d')
out_dir = f'{hist_base}/{gen_date}'
os.makedirs(out_dir, exist_ok=True)

# 数据目录：优先当天，其次回退到最近有sector数据的日期
data_dir = out_dir
data_date = gen_date
if not os.path.exists(f'{out_dir}/results_sector.json'):
    dirs = sorted([d for d in os.listdir(hist_base) if os.path.isdir(f'{hist_base}/{d}') and d.startswith('202')], reverse=True)
    for d in dirs:
        if os.path.exists(f'{hist_base}/{d}/results_sector.json'):
            data_dir = f'{hist_base}/{d}'
            data_date = d
            break

def load(p):
    return json.load(open(p,'r',encoding='utf-8')) if os.path.exists(p) else []

sector_l2 = load(f'{data_dir}/results_sector.json')
sector_l3 = load(f'{data_dir}/results_sector_l3.json')

def build_rows(data):
    mx = max((abs(r['r20']) for r in data), default=1) or 1
    out = []
    for i, r in enumerate(data):
        bar = (f'<span class="bar-track"><span class="bar-fill {"bar-up" if r["r20"]>0 else "bar-dn"}" '
               f'style="width:{abs(r["r20"])/mx*100:.0f}%"></span></span>')
        out.append(
        f'<tr data-r3="{r["r3"]}" data-r5="{r["r5"]}" data-r10="{r["r10"]}" data-r20="{r["r20"]}">'
        f'<td class="mono" style="color:var(--text-muted)">{i+1}</td>'
        f'<td><span title="板块代码 {r.get("code","")}">{r["name"]}</span><span class="sec-code">{r.get("code","")}</span></td>'
        f'<td class="mono {"up" if r["r3"]>0 else "dn"}">{r["r3"]:+.1f}%</td>'
        f'<td class="mono {"up" if r["r5"]>0 else "dn"}">{r["r5"]:+.1f}%</td>'
        f'<td class="mono {"up" if r["r10"]>0 else "dn"}">{r["r10"]:+.1f}%</td>'
        f'<td class="mono {"up" if r["r20"]>0 else "dn"}"><div class="chg-cell"><span>{r["r20"]:+.1f}%</span>{bar}</div></td></tr>')
    return '\n'.join(out)

rows_l2 = build_rows(sector_l2)
rows_l3 = build_rows(sector_l3)

html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>行业排行 {gen_date}</title>
<link rel="stylesheet" href="../../style.css">
<style>
.sector-header{{text-align:center;margin-bottom:24px}}
.sector-header h1{{font-size:24px;margin-bottom:4px}}
.sector-header h1 .accent{{color:var(--accent)}}
.sector-header .subtitle{{font-size:13px;color:var(--text-tertiary)}}
.tabs{{display:flex;gap:0;margin-bottom:16px;justify-content:center}}
.tab{{padding:8px 20px;background:var(--bg-card);border:1px solid var(--border);color:var(--text-tertiary);cursor:pointer;font-size:14px;border-radius:6px 6px 0 0;border-bottom:none;margin-right:4px;transition:all 0.2s}}
.tab:hover{{background:var(--bg-hover)}}
.tab.active{{background:var(--accent);color:#fff;border-color:var(--accent);font-weight:600}}
.sector-table{{width:100%;border-collapse:collapse;font-size:13px}}
.sector-table th{{text-align:left;padding:9px 12px;color:var(--text-tertiary);font-weight:600;border-bottom:2px solid rgba(56,61,77,0.3);cursor:pointer;user-select:none;font-size:12px}}
.sector-table th:hover{{color:var(--accent)}}
.sector-table th.sorted::after{{content:" ▼";font-size:10px;color:var(--accent)}}
.sector-table td{{padding:9px 12px;border-bottom:1px solid rgba(56,61,77,0.12);vertical-align:middle}}
.sector-table tr:hover td{{background:rgba(102,153,224,0.05)}}
.up{{color:#e0245e}}.dn{{color:#17bf63}}
#tbl-l3{{display:none}}
.back-link{{display:inline-flex;align-items:center;gap:6px;color:var(--accent);text-decoration:none;font-size:13px;margin-bottom:16px}}
.back-link:hover{{text-decoration:underline}}
@media(max-width:768px){{.sector-table{{font-size:11px}}.sector-table th,.sector-table td{{padding:6px 4px}}}}
</style>
</head>
<body class="entrance-ready">

<div class="top-accent-strip"></div>
<div class="deco-streak deco-streak-h"></div>
<div class="deco-orb deco-orb-subtle"></div>

<div class="content-panel">

<nav class="sub-nav">
  <span class="sub-nav-home" onclick="window.location.href='../../index.html'">HOME_</span>
  <span class="sub-nav-modules" onclick="openModuleMenu()">MODULES ▾</span>
  <span class="sub-nav-switch" onclick="window.location.href='../每日选股/index.html'">SWITCH_</span>
</nav>

<!-- MODULES Overlay -->
<div class="sub-overlay-bg" id="overlayBg" onclick="closeModuleMenu()"></div>
<div class="sub-overlay-menu" id="overlayMenu">
  <div class="sub-menu-close" onclick="closeModuleMenu()"></div>
  <div class="sub-menu-section">策略模块</div>
  <a class="sub-menu-link" href="../../每日选股/index.html"><span class="sub-menu-dot" style="background:#6699E0"></span>每日选股策略</a>
  <a class="sub-menu-link" href="../../行业排行/index.html"><span class="sub-menu-dot"></span>行业排行</a>
  <a class="sub-menu-link" href="../../价值投资/index.html"><span class="sub-menu-dot"></span>价值投资</a>
  <a class="sub-menu-link" href="../../回测报告/index.html"><span class="sub-menu-dot"></span>回测报告</a>
  <div class="sub-menu-section">系统</div>
  <a class="sub-menu-link" href="../../index.html"><span class="sub-menu-dot"></span>首页</a>
  <a class="sub-menu-link" href="../../历史数据/index.html"><span class="sub-menu-dot"></span>历史数据</a>
</div>

<main>
  <div class="sector-header">
    <a href="../../index.html" class="back-link">← 返回首页</a>
    <h1>行业排行 <span class="accent">{data_date}</span></h1>
    <div class="subtitle">共 {len(sector_l2)} 个二级 · {len(sector_l3)} 个三级 | 点击表头排序</div>
  </div>

  <div class="tabs">
    <div class="tab active" onclick="switchTab('l2')">二级行业 ({len(sector_l2)})</div>
    <div class="tab" onclick="switchTab('l3')">三级行业 ({len(sector_l3)})</div>
  </div>

  <div id="tbl-wrapper">
    <table id="tbl-l2" class="sector-table">
      <thead><tr><th>#</th><th>行业</th><th onclick="sortTable('l2',2)">3日涨跌</th><th onclick="sortTable('l2',3)">5日涨跌</th><th onclick="sortTable('l2',4)">10日涨跌</th><th onclick="sortTable('l2',5)" class="sorted">20日涨跌</th></tr></thead>
      <tbody>{rows_l2}</tbody>
    </table>
    <table id="tbl-l3" class="sector-table">
      <thead><tr><th>#</th><th>行业</th><th onclick="sortTable('l3',2)">3日涨跌</th><th onclick="sortTable('l3',3)">5日涨跌</th><th onclick="sortTable('l3',4)">10日涨跌</th><th onclick="sortTable('l3',5)" class="sorted">20日涨跌</th></tr></thead>
      <tbody>{rows_l3}</tbody>
    </table>
  </div>
</main>
</div>

<div class="footer-bar">CLAW v2.0 | {gen_date}</div>

<script>
let sortDir={{l2:{{}},l3:{{}}}};
function switchTab(tab){{
  document.getElementById('tbl-l2').style.display=tab==='l2'?'table':'none';
  document.getElementById('tbl-l3').style.display=tab==='l3'?'table':'none';
  document.querySelectorAll('.tab').forEach(function(t){{
    var isActive=(tab==='l2'&&t.textContent.indexOf('二级')>=0)||(tab==='l3'&&t.textContent.indexOf('三级')>=0);
    if(isActive)t.classList.add('active');else t.classList.remove('active');
  }});
}}
function sortTable(tbl,col){{
  var t=document.getElementById('tbl-'+tbl);
  var rows=Array.prototype.slice.call(t.querySelectorAll('tbody tr'));
  var key=['','','r3','r5','r10','r20'][col];
  sortDir[tbl]=sortDir[tbl]||Object();
  sortDir[tbl][col]=sortDir[tbl][col]===-1?1:-1;
  rows.sort(function(a,b){{return (parseFloat(a.dataset[key])-parseFloat(b.dataset[key]))*sortDir[tbl][col]}});
  rows.forEach(function(r){{t.querySelector('tbody').appendChild(r)}});
  t.querySelectorAll('th').forEach(function(h){{h.classList.remove('sorted')}});
  t.querySelectorAll('th')[col].classList.add('sorted');
}}
function openModuleMenu(){{document.getElementById('overlayBg').classList.add('open');document.getElementById('overlayMenu').classList.add('open')}}
function closeModuleMenu(){{document.getElementById('overlayBg').classList.remove('open');document.getElementById('overlayMenu').classList.remove('open')}}
document.addEventListener('keydown',function(e){{if(e.key==='Escape')closeModuleMenu()}});
var moduleUrls=['../../每日选股/index.html','../../行业排行/index.html','../../价值投资/index.html','../../回测报告/index.html','../../历史数据/index.html'];
var currentModIdx=0;
function cycleModule(){{currentModIdx=(currentModIdx+1)%moduleUrls.length;window.location.href=moduleUrls[currentModIdx]}}
</script>
</body></html>'''

with open(f'{out_dir}/sector.html', 'w', encoding='utf-8') as f:
    f.write(html)
print(f'行业页面: {out_dir}/sector.html (L2:{len(sector_l2)} L3:{len(sector_l3)})')
