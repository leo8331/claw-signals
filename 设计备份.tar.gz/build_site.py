"""CLAW网站生成器 — 设计版(style.css + overlay菜单)"""
import json, os, sys, subprocess
from datetime import datetime

gen_date = datetime.now().strftime('%Y-%m-%d')
out_dir = f'D:/tdx临时/历史数据/{gen_date}'
os.makedirs(out_dir, exist_ok=True)

# 收据目录：优先当天，其次回退（数据可能来自不同日期）
def find_data_dir():
    hist = 'D:/tdx临时/历史数据'
    dirs = sorted([d for d in os.listdir(hist) if os.path.isdir(f'{hist}/{d}') and d.startswith('202')], reverse=True)
    for d in dirs:
        dd = f'{hist}/{d}'
        if os.path.exists(f'{dd}/results_h3.json') or os.path.exists(f'{dd}/results_g.json') or os.path.exists(f'{dd}/results_m5.json'):
            return dd, d
    return out_dir, gen_date  # fallback: write empty

data_dir, data_date = find_data_dir()

def clean(c):
    return c.replace('.SH','').replace('.SZ','').replace('sh.','').replace('sz.','')

# 板块映射
sector_map = {}
for cache_path in ['D:/tdx临时/sector_l2_cache.json', 'D:/tdx临时/sector_cache.json']:
    if os.path.exists(cache_path):
        sector_map = json.load(open(cache_path,'r',encoding='utf-8'))
        break
if not sector_map and os.path.exists(r'C:\Users\leo83\Desktop\交易\指标\claw\stock_sector_mapping.json'):
    with open(r'C:\Users\leo83\Desktop\交易\指标\claw\stock_sector_mapping.json','r',encoding='utf-8') as f:
        raw_map = json.load(f)
        for k,v in raw_map.items():
            if isinstance(v,list) and v:
                sector_map[clean(k)] = v[0].get('sector_name','')[:8]
    json.dump(sector_map, open('D:/tdx临时/sector_cache.json','w'), ensure_ascii=False)

# 股票名称
name_map = {}
sys.path.insert(0, r'E:\new_tdx_mock\PYPlugins\user')
from tqcenter import tq
tq.initialize(r'E:\new_tdx_mock\PYPlugins\user\build_site.py')

def load_json(name):
    p = f'{data_dir}/results_{name}.json'
    return json.load(open(p,'r',encoding='utf-8')) if os.path.exists(p) else []

h3r=load_json('h3'); h3=h3r.get('ht_rise',h3r.get('all',[])) if isinstance(h3r,dict) else h3r
g=load_json('g'); m5=load_json('m5')

def add_suf(c):
    c = clean(c)
    return c+'.SH' if c.startswith(('6','68')) else c+'.SZ'

all_codes = set(r['code'] for d in [h3,g,m5] for r in d)
for i,code in enumerate(all_codes):
    try:
        info = tq.get_stock_info(stock_code=add_suf(code), field_list=['Name'])
        name_map[clean(code)] = info.get('Name', clean(code))
    except:
        name_map[clean(code)] = clean(code)
tq.close()
print(f'名称:{len(name_map)} H3:{len(h3)} G:{len(g)} M5:{len(m5)}')

# 行业标签
tag_path = f'{data_dir}/industry_tags.json'
if not os.path.exists(tag_path):
    for d in sorted([d for d in os.listdir('D:/tdx临时/历史数据') if os.path.isdir(f'D:/tdx临时/历史数据/{d}') and d.startswith('202')], reverse=True):
        tp = f'D:/tdx临时/历史数据/{d}/industry_tags.json'
        if os.path.exists(tp): tag_path = tp; break
name_tags = {}
if os.path.exists(tag_path):
    raw_tags = json.load(open(tag_path,'r',encoding='utf-8'))
    for code,info in raw_tags.items():
        name = info.get('name','')
        if name: name_tags[name] = info

def sector_tag(code, strategy='h3'):
    c = clean(code)
    sname = sector_map.get(c,'')
    it = name_tags.get(sname, {})
    if not it: return ('','','','')
    ph = it.get('phase','')
    pri = it.get('priority',1)
    sl_adj = it.get('sl_adj',7.0)
    risk = it.get('risk','正常')
    # 行业阶段 pill (替代 emoji 箭头): ↑↑/↑↑↑→强势 ↓↓/↓↓↓→弱势 其他→中性
    if ph.count('↑') >= 2:
        stage_html = '<span class="stage-pill st-strong">强势</span>'
    elif ph.count('↓') >= 2:
        stage_html = '<span class="stage-pill st-weak">弱势</span>'
    else:
        stage_html = '<span class="stage-pill st-mid">中性</span>'
    pri_html = f'<span class="prio">P{pri}</span>'
    # 仓位·止损 合并列 (个股仓位 基于行业优先级: V5报告 §3.3)
    pos_pct = {3:'20%', 2:'10%', 1:'10%', 0:'0%'}.get(pri,'-')
    pos_col = {3:'var(--green)', 2:'var(--accent)', 1:'var(--text-tertiary)', 0:'var(--red)'}.get(pri,'var(--text-muted)')
    possl_html = f'<span style="color:{pos_col};font-weight:600">{pos_pct}</span> <span style="color:var(--text-muted)">· SL {sl_adj:.0f}%</span>'
    if risk=='⚠冰点':
        risk_html='<span class="stage-pill st-weak">⚠冰点</span>'
    elif risk=='⚡过热':
        risk_html='<span class="stage-pill st-strong">⚡过热</span>'
    else:
        risk_html='<span style="color:var(--text-muted);font-size:10px">-</span>'
    return (stage_html, pri_html, possl_html, risk_html)

def code_cls(c):
    return 'code-sh' if c.startswith(('6','9')) else 'code-sz'

def sign_col(v):
    return 'var(--red)' if v > 0 else 'var(--green)' if v < 0 else 'var(--text-tertiary)'

def tr(i,code,vals,strategy='h3',ind_cols=True):
    c = clean(code)
    extra = ''
    if ind_cols:
        stage,pri,possl,risk = sector_tag(c, strategy)
        extra = f'<td>{stage}{pri}</td><td class="mono">{possl}</td><td>{risk}</td>'
    return f'<tr><td class="mono" style="color:var(--text-muted)">{i+1}</td><td><span class="{code_cls(c)}">{c}</span></td><td>{name_map.get(c,c)}</td><td style="color:var(--text-tertiary)">{sector_map.get(c,"")}</td>{extra}{"".join(f"<td class=\"mono\">{v}</td>" for v in vals)}</tr>'

h3r='\n'.join(tr(i,r['code'],[f'¥{r["close"]:.2f}',f'{r.get("vr",""):.2f}',(f'<span style="color:{sign_col(r["ma60d"])}">{r["ma60d"]:+.1f}%</span>' if isinstance(r.get('ma60d'),(int,float)) else '')],'h3') for i,r in enumerate(h3[:15]))
gr='\n'.join(tr(i,r['code'],[f'¥{r["close"]:.2f}',f'{r.get("adx",""):.1f}',r.get('module','')],'g') for i,r in enumerate(g[:15])) or '<tr><td colspan=10 style=color:#556>暂无</td></tr>'
m5r='\n'.join(tr(i,r['code'],[f'¥{r["close"]:.2f}',f'{r.get("proba",""):.3f}',(f'<span style="color:{sign_col(r["dret"])}">{r["dret"]:+.1f}%</span>' if isinstance(r.get('dret'),(int,float)) else ''),f'★★' if r.get("proba",0)>=0.6 else '★' if r.get("proba",0)>=0.5 else ''],'v5') for i,r in enumerate(m5[:15])) or '<tr><td colspan=11 style=color:#556>暂无</td></tr>'

# 今日概览卡
ops_html = f'''<div class="ops-row">
  <div class="ops-card"><span class="dot" style="background:var(--green)"></span><div><div class="l">H3 信号</div><div class="n" style="color:var(--green)">{len(h3)}</div></div></div>
  <div class="ops-card"><span class="dot" style="background:var(--accent)"></span><div><div class="l">G 信号</div><div class="n" style="color:var(--accent)">{len(g)}</div></div></div>
  <div class="ops-card"><span class="dot" style="background:var(--red)"></span><div><div class="l">V5 信号</div><div class="n" style="color:var(--red)">{len(m5)}</div></div></div>
  <div class="ops-card"><span class="dot" style="background:var(--orange)"></span><div><div class="l">数据日期</div><div class="n" style="color:var(--orange);font-size:16px;padding-top:4px">{data_date[5:]}</div></div></div>
</div>'''

html=f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>CLAW {gen_date}</title>
<link rel="stylesheet" href="../../style.css">
<style>
.page-header h1{{font-size:24px;margin-bottom:4px}}
.page-header h1 .accent{{color:var(--accent)}}
.page-header .subtitle{{font-size:13px;color:var(--text-tertiary);margin-bottom:20px}}
.strat-card{{background:linear-gradient(135deg,rgba(20,26,46,0.95) 0%,rgba(28,38,60,0.95) 100%);border:1px solid var(--border);border-radius:12px;padding:18px 20px;margin-bottom:18px}}
.strat-card h2{{font-size:15px;margin-bottom:4px}}
.strat-card .desc{{font-size:12px;color:var(--text-tertiary);margin-bottom:12px;line-height:1.6}}
.stock-table{{width:100%;border-collapse:collapse;font-size:13px}}
.stock-table th{{text-align:left;padding:8px 10px;color:var(--text-tertiary);font-weight:600;font-size:12px;border-bottom:2px solid rgba(56,61,77,0.3);white-space:nowrap}}
.stock-table td{{padding:9px 10px;border-bottom:1px solid rgba(56,61,77,0.12);font-size:13px;vertical-align:middle}}
.stock-table tr:hover td{{background:rgba(102,153,224,0.05)}}
.tag-sm{{font-size:10px;padding:1px 6px;border-radius:3px;color:#fff;display:inline-block}}
.tag-h3{{background:#17bf63}}.tag-g{{background:#6699E0}}.tag-v5{{background:#e0245e}}
@media(max-width:768px){{.stock-table{{font-size:11px}}.stock-table th,.stock-table td{{padding:6px 4px}}}}
</style>
</head>
<body class="entrance-ready">

<div class="top-accent-strip"></div>
<div class="deco-streak deco-streak-h"></div>
<div class="deco-orb deco-orb-subtle"></div>

<div class="content-panel">

<nav class="sub-nav">
  <span class="sub-nav-home" onclick="window.location.href='../../index.html'">HOME_</span>
  <span class="sub-nav-modules" onclick="openModuleMenu()">MODULES ▾</span>
  <span class="sub-nav-switch" onclick="window.location.href='../行业排行/index.html'">SWITCH_</span>
</nav>

<!-- MODULES Overlay -->
<div class="sub-overlay-bg" id="overlayBg" onclick="closeModuleMenu()"></div>
<div class="sub-overlay-menu" id="overlayMenu">
  <div class="sub-menu-close" onclick="closeModuleMenu()"></div>
  <div class="sub-menu-section">策略模块</div>
  <a class="sub-menu-link" href="../../每日选股/index.html"><span class="sub-menu-dot" style="background:#6699E0"></span>每日选股策略</a>
  <a class="sub-menu-link" href="../../行业排行/index.html"><span class="sub-menu-dot"></span>行业排行</a>
  <a class="sub-menu-link" href="../../价值投资/index.html"><span class="sub-menu-dot"></span>价值投资</a>
  <a class="sub-menu-link" href="../../回测报告/index.html"><span class="sub-menu-dot"></span>回测报告</a>
  <div class="sub-menu-section">系统</div>
  <a class="sub-menu-link" href="../../index.html"><span class="sub-menu-dot"></span>首页</a>
  <a class="sub-menu-link" href="../../历史数据/index.html"><span class="sub-menu-dot"></span>历史数据</a>
</div>

<main>
  <div class="page-header" style="text-align:center">
    <a href="../../index.html" class="back-home" style="margin-bottom:8px;display:inline-flex;">← 返回首页</a>
    <h1>每日选股信号 <span class="accent">{gen_date}</span></h1>
    <div class="subtitle">全市场自动扫描 · H3 / G变体 / V5-ML 三策略信号</div>
  </div>

  {ops_html}

  <div class="strat-card strat-h3">
    <h2><span class="tag-sm tag-h3">H3</span> 振幅加速</h2>
    <div class="desc">ideal_amp>1.5 | L1板块 | MC>80亿 | ★★★牛市优先 ⚡过热谨慎</div>
    <div class="table-wrap"><table class="stock-table"><tr><th>#</th><th>代码</th><th>名称</th><th>板块</th><th>行业·阶段</th><th>仓位·止损</th><th>幅度风险</th><th>收盘</th><th>量能比</th><th>MA60%</th></tr>{h3r}</table></div>
  </div>

  <div class="strat-card strat-g">
    <h2><span class="tag-sm tag-g">G变体</span> 趋势质量</h2>
    <div class="desc">VG+11因子 | 5天冷却 | L1板块 | MC&gt;80亿</div>
    <div class="table-wrap"><table class="stock-table"><tr><th>#</th><th>代码</th><th>名称</th><th>板块</th><th>行业·阶段</th><th>仓位·止损</th><th>幅度风险</th><th>收盘</th><th>ADX</th><th>模块</th></tr>{gr}</table></div>
  </div>

  <div class="strat-card strat-v5">
    <h2><span class="tag-sm tag-v5">V5-ML</span> 量价突破</h2>
    <div class="desc">ML proba排名 | ★★★优先 ✘回避 | ML>0.60加成</div>
    <div class="table-wrap"><table class="stock-table"><tr><th>#</th><th>代码</th><th>名称</th><th>板块</th><th>行业·阶段</th><th>仓位·止损</th><th>幅度风险</th><th>收盘</th><th>ML</th><th>日收益</th><th>评级</th></tr>{m5r}</table></div>
  </div>
</main>
</div>

<div class="footer-bar">CLAW v2.0 | {gen_date} | ⚠ 信号仅供参考</div>

<script>
function openModuleMenu(){{document.getElementById('overlayBg').classList.add('open');document.getElementById('overlayMenu').classList.add('open')}}
function closeModuleMenu(){{document.getElementById('overlayBg').classList.remove('open');document.getElementById('overlayMenu').classList.remove('open')}}
document.addEventListener('keydown',function(e){{if(e.key==='Escape')closeModuleMenu()}});
var moduleUrls=['../../每日选股/index.html','../../行业排行/index.html','../../价值投资/index.html','../../回测报告/index.html','../../历史数据/index.html'];
var currentModIdx=0;
function cycleModule(){{currentModIdx=(currentModIdx+1)%moduleUrls.length;window.location.href=moduleUrls[currentModIdx]}}
</script>
</body></html>'''

with open(f'{out_dir}/index.html','w',encoding='utf-8') as f:f.write(html)
print(f'网页: {out_dir}/index.html')

# 行业排行
exec(open(r'E:\new_tdx_mock\PYPlugins\user\build_sector.py', encoding='utf-8').read())

# 首页 + 跳转页
exec(open(r'E:\new_tdx_mock\PYPlugins\user\build_home.py', encoding='utf-8').read())

# Git
try:
    subprocess.run(['git','-C','D:/tdx临时','add','-A'],check=True)
    subprocess.run(['git','-C','D:/tdx临时','commit','-m',f'Auto {gen_date}'],check=True)
    subprocess.run(['git','-C','D:/tdx临时','push'],check=True)
    print('已推送')
except Exception as e:
    print(f'Git错误: {e}')
